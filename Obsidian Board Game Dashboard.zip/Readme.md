## 📘 **Obsidian Board Game Dashboard — Installation & Setup Guide**

This starter kit gives you a clean, interactive way to track your board game collection inside Obsidian. It includes:

- **Board Game Dashboard** — browse, filter, search, and rate your games
- **Add New Game** — a form that creates new game notes automatically
- **Board Games/** — the folder where all game notes will be stored

Everything runs on **DataviewJS** and core Obsidian features. No external scripts, no QuickAdd, no configuration steps.

---

> **Update – March 19, 2026**  
> Added an enhanced **v2** version of the Add New Game form (`Board Game - Add New Game v2.md`).  
> It automatically generates game notes with a clean 3-column layout (cover image left, categories middle, stats right).  
> The original standard form is still included — choose whichever you prefer (see **How to Add a New Game** below for details).  
> Also refreshed the example game (**Botany.md**) and screenshots to show the enhanced layout.

---

## 📁 Folder Contents

When you unzip the download, you’ll see:

```
Board Games/   ← Folder where your game notes will live
		Botany.md   ← example game
	Board Game - Add New Game.md
	Board Game - Add New Game v2.md
	Board Game - Dashboard.md
	Readme.md
```

---

## 🎨 Theme and Appearance Settings to Match the Screenshots

These settings are optional, but they will make your vault look like the screenshots shown in this guide. They don’t affect functionality—only appearance and layout.

### **Theme**

The screenshots use the **Fancy A Story** theme with these style presets:

- **Board Game Dashboard:** _Art Deco — Light Silver_
- **Movie Dashboard:** _Art Deco — Dark Chocolate_

The dashboards work with any theme; these are just the ones used in the screenshots.

### **Appearance Settings**

These settings affect layout, spacing, and how clean the pages look:

- Appearance → Inline title → **Off**
- Editor → Readable line length → **Off**
- Editor → Properties in document → **Hidden**
- Core plugins → Page preview → **Off**

### **Editor Behavior**

These settings ensure the dashboard and forms open in the correct mode:

- Editor → Default view for new tabs → **Reading view**
- Editor → Default editing mode → **Source mode**

These match the environment used to create the screenshots and help the dashboards display cleanly and consistently.

---

## Screenshots

(Updated to show the enhanced v2 layout in the example game note)

![Add Game Form – Part 1](screenshots/Board%20Game%20Form%201.png)
![Add Game Form – Part 2](screenshots/Board%20Game%20Form%202.png)

![Dashboard – Features Part 1](screenshots/Board%20Game%20Dashboard%201.png)
![Dashboard – Features Part 2](screenshots/Board%20Game%20Dashboard%202.png)

![Game Page – Details Part 1](screenshots/Board%20Game%20Page%201.png)
![Game Page – Details Part 2](screenshots/Board%20Game%20Page%202.png)

---

## 🚀 Installation (2 minutes)

Follow these steps:

1. **Unzip the download.**
2. **Copy these files and folders into the root of your Obsidian vault** (the top level).
	You can skip copying the Readme.md if you’ve already read it or don’t need it in your vault.

```
    Board Games/
		    Botany.md   ← example game
	    Board Game - Add New Game.md
	    Board Game - Add New Game v2.md
	    Board Game - Dashboard.md
```

3. Open Obsidian and make sure the plugin **Dataview** is installed and enabled.
    - Settings → Community Plugins → Browse → search “Dataview”
    - Enable **Dataview**
    - Settings → Dataview → **Enable JavaScript Queries** (required for the dashboard and form)
4. Open **Board Game Dashboard** or **Board Game – Add New Game** and start using the system.

That’s it. No configuration, no renaming, no plugin setup beyond Dataview.

---

## 📝 How to Add a New Game

You now have **two form options** — both do the same core job (create a new game note with YAML, description, pros/cons, etc.), but differ in the generated note's appearance:

1. **Standard Form** (`Board Game - Add New Game.md`)  
   - Creates clean, simple notes: YAML + title + basic cover image embed + text sections.  
   - Great if you prefer minimal styling or want to customize layouts yourself later.

2. **Enhanced Form v2** (`Board Game - Add New Game v2.md`) ← Recommended for new users!  
   - Same easy inputs, but auto-generates a **beautiful 3-column DataviewJS layout** in every new note:  
     - Left: Cover image  
     - Middle: Categories card (split from your / delimited input)  
     - Right: Stats card (designer, solo/co-op, player count, play time)  
   - Pros/cons show as neat side-by-side panels below the grid.  
   - Makes your collection look polished right away.

**Steps (for either form):**
1. Open the form note you want to use.
2. Fill out the fields (title required; others optional).
3. Click **Create Board Game**.
4. A new note appears in the `Board Games/` folder — open it to see the result!

The dashboard reads both styles automatically — mix and match as you like.

---

## 📊 Using the Dashboard

Open **Board Game Dashboard.md** to:

- Browse your collection
- Filter by category
- Search by title
- Page through large collections
- Toggle “Show All” mode
- Click **🎲 Surprise Me!** to open a random game
- Adjust ratings with a slider (saved instantly to the note)

The dashboard updates itself every time you add or edit a game.

---

## 🗂️ Customizing the System (Keep It Simple)

This kit is designed to be easy to use right away — and easy to tweak if you want.

**The safest & most common change: Rename the games folder**  
If you’d rather call it “My Games”, “Collection”, “Boardgames”, or anything else:

1. Open **Board Game - Add New Game.md**  
   Find this line near the top:  
   const BOARD_GAME_FOLDER = "Board Games";  
   Change "Board Games" to your preferred name (keep the quotes).

2. Open **Board Game Dashboard.md**  
   Find this line:  
   const allGames = dv.pages('"Board Games"')  
   Change "Board Games" to match exactly what you picked above.

3. (If you already added games) Rename or move the “Board Games” folder in your vault to the new name.

That’s all it takes — the form will save to the new location, and the dashboard will read from it.

**Want to do more?**  
You can safely edit labels, add/remove tags/categories in the notes themselves, or experiment with the form/dashboard code. Everything is plain text — if something breaks, just replace the file from your backup. For bigger changes (like adding new fields to track), search online for “Obsidian Dataview frontmatter” or “DataviewJS tutorial” — there are tons of friendly guides.

Have fun with your board game collection! 🎲

---

## 🧩 Troubleshooting

**Dashboard is empty**

- Make sure your game notes are inside the `Board Games/` folder
- Make sure Dataview is enabled
- Make sure DataviewJS is enabled

**Images not showing**

- Check that your Cover Image URL is valid
- Try using a direct image link (ending in .jpg or .png)

**Rating slider doesn’t update**

The most common cause is that the game note was edited in a way that removed the information block at the top of the file. Each game page needs that block so the dashboard knows where to save your rating.

To fix it:

- Open the game note
    
- Make sure the top of the file still contains the information section created by the Add Game form
    
- If it’s missing, recreate the game using the form

---

## 🎉 Enjoy Your Board Game Tracker

This system is designed to be simple, clean, and easy to extend. You can customize it as much or as little as you want.
