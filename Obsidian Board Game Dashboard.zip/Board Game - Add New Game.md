# 🎲 **New Board Game Entry Form**

```dataviewjs
(async () => {
  // Add custom CSS for card layout with third-column fix and your Pros/Cons adjustment
  const style = document.createElement("style");
  style.id = "boardgame-entry-card-style-" + Date.now();
  style.textContent = `
    .boardgame-entry-card {
      background: var(--background-secondary);
      border: 1px solid var(--background-modifier-border);
      border-radius: 6px;
      padding: 1rem;
      margin: 0;
      grid-column: 1 / -1;
      box-sizing: border-box; /* Ensure padding doesn't cause overflow */
      width: 100%; /* Explicitly constrain to parent width */
    }
    .boardgame-entry-card .header {
      font-size: 1.25rem;
      font-weight: 600;
      color: var(--text-normal);
      margin-bottom: 20px;
      text-align: center;
    }
    .boardgame-entry-card .grid {
      display: grid;
      grid-template-columns: repeat(3, calc(33.33% - 8px)); /* Adjust for gap */
      gap: 12px; /* Consistent with Board Games Played */
      margin-bottom: 1rem;
      width: 100%; /* Ensure grid stays within card */
      box-sizing: border-box;
    }
    .boardgame-entry-card .input-wrapper {
      display: flex;
      flex-direction: column;
      width: 100%; /* Ensure wrapper stays within column */
      box-sizing: border-box;
    }
    .boardgame-entry-card .input-label {
      font-weight: normal;
      color: var(--text-muted);
      margin-bottom: 4px;
    }
    .boardgame-entry-card input,
    .boardgame-entry-card textarea {
      padding: 6px;
      border-radius: 4px;
      border: 1px solid var(--background-modifier-border);
      background: var(--background-primary);
      color: var(--text-normal);
      width: 100%;
      box-sizing: border-box; /* Prevent padding from causing overflow */
    }
    .boardgame-entry-card textarea {
      height: 80px;
      resize: vertical;
    }
    .boardgame-entry-card .pros-cons-grid {
      display: grid;
      grid-template-columns: 49% 49%; /* Your fix for Pros/Cons */
      gap: 12px; /* Match grid gap */
      margin-top: 1rem;
      width: 100%; /* Match Description width */
      box-sizing: border-box;
    }
    .boardgame-entry-card .description-wrapper {
      width: 100%; /* Match Pros/Cons width */
      box-sizing: border-box;
    }
    .boardgame-entry-card .submit-button {
      width: 100%;
      margin-top: 16px;
      padding: 8px 16px;
      border-radius: 6px;
      cursor: pointer;
      font-size: 0.9em;
    }

    .boardgame-entry-card .message {
      margin-top: 10px;
      font-size: 0.9rem;
      color: var(--text-accent);
    }
  `;
  document.head.appendChild(style);

  const BOARD_GAME_FOLDER = "Board Games";

  // Create card container
  const root = dv.container;
  root.empty();
  const card = root.createEl("div", { cls: "boardgame-entry-card" });

  // ── Header
  card.createEl("div", { cls: "header", text: "➕ New Board Game Entry" });

  // ── Input Grid
  const grid = card.createEl("div", { cls: "grid" });

  const inputs = {};
  const makeInput = (label, key, placeholder = "") => {
    const wrapper = grid.createEl("div", { cls: "input-wrapper" });
    wrapper.createEl("div", { cls: "input-label", text: label });
    const input = wrapper.createEl("input", { type: "text", attr: { placeholder } });
    inputs[key] = input;
  };

  // ── Input Fields
  makeInput("Title", "title");
  makeInput("Designer(s)", "designer", "e.g. Randy Flynn");
  makeInput("Year Published", "year");
  makeInput("Cover Image URL", "cover", "https://...");
  makeInput("Category", "category", "Use slashes: Animal / Puzzle / Nature / etc.");
  makeInput("Solo Play", "solo", "Yes or No");
  makeInput("Co-op", "coop", "Yes or No");
  makeInput("Player Count", "players", "e.g. 1 – 4");
  makeInput("Play Time", "playtime", "e.g. 30 – 45");
  makeInput("Star Rating", "rating");
  makeInput("Tag 1", "tag1", "Puzzle");
  makeInput("Tag 2", "tag2");
  makeInput("Tag 3", "tag3");
  makeInput("Tag 4", "tag4");
  makeInput("Tag 5", "tag5");
  makeInput("Tag 6", "tag6");
  makeInput("Purchase Site", "site", "Amazon");
  makeInput("Purchase URL", "url", "https://...");

  // ── Pros / Cons
  const prosConsWrapper = card.createEl("div", { cls: "pros-cons-grid" });

  const prosBox = prosConsWrapper.createEl("div", { cls: "input-wrapper" });
  prosBox.createEl("div", { cls: "input-label", text: "👍 Pros" });
  const prosArea = prosBox.createEl("textarea");

  const consBox = prosConsWrapper.createEl("div", { cls: "input-wrapper" });
  consBox.createEl("div", { cls: "input-label", text: "👎 Cons" });
  const consArea = consBox.createEl("textarea");

  // ── Description
  const descWrapper = card.createEl("div", { cls: "input-wrapper description-wrapper" });
  descWrapper.createEl("div", { cls: "input-label", text: "Description" });
  const description = descWrapper.createEl("textarea", { attr: { style: "height: 100px;" } });

  // ── Submit Button + Feedback
  const btn = card.createEl("button", { cls: "submit-button", text: "➕ Create Board Game" });
  const msg = card.createEl("div", { cls: "message" });

  // ── Submit Logic
  btn.onclick = async () => {
    const rawTitle = inputs.title.value.trim();
    if (!rawTitle) {
      msg.textContent = "⚠️ Please enter a Title.";
      return;
    }

    const safeTitle = rawTitle.replace(/:/g, " -");
    const path = `${BOARD_GAME_FOLDER}/${safeTitle}.md`;

    const tags = [inputs.tag1, inputs.tag2, inputs.tag3, inputs.tag4, inputs.tag5, inputs.tag6]
      .map(t => t.value.trim().replace(/\s+/g, "-"))
      .filter(Boolean)
      .map(tag => `Board-Games/${tag}`);

    const prosList = prosArea.value.trim().split("\n").map(p => p.trim()).filter(Boolean);
    const consList = consArea.value.trim().split("\n").map(c => c.trim()).filter(Boolean);

    const yaml = [
      "---",
      `Title: ${safeTitle}`,
      `Designer: ${inputs.designer.value.trim()}`,
      `Year-Published: ${inputs.year.value.trim()}`,
      `Cover-Img: ${inputs.cover.value.trim()}`,
      `Category: ${inputs.category.value.trim()}`,
      `Solo-Play: ${inputs.solo.value.trim()}`,
      `Co-op: ${inputs.coop.value.trim()}`,
      `Player-Count: ${inputs.players.value.trim()}`,
      `Play-Time: ${inputs.playtime.value.trim()}`,
      `Star-Rating: ${inputs.rating.value.trim()}`,
      "tags:",
      ...tags.map(tag => `  - ${tag}`),
      "pros:",
      ...prosList.map(p => `  - ${p}`),
      "cons:",
      ...consList.map(c => `  - ${c}`),
      `Purchase-URL: ${inputs.url.value.trim()}`,
      `Purchase-Site: ${inputs.site.value.trim()}`,
      "---"
    ];

    const body = [
      `### ${rawTitle}`,
      ``,
      `![${rawTitle} cover|200](${inputs.cover.value.trim()})`,
      ``,
      `---`, // Add this line for the horizontal rule
      description.value.trim(),
      ``,
      "<!-- Pros / Cons Panel -->",
      `<table style="width:100%;border-collapse:collapse;margin:2rem 0;"><tr>`,
      `<td style="width:50%;vertical-align:top;padding:15 1rem;"><br><b>Pros:</b><div markdown="1" style="background:var(--background-modifier-border);padding:1rem;border-radius:6px;">`,
      ...prosList.map(p => `- ${p}`),
      `</div></td>`,
      `<td style="width:50%;vertical-align:top;padding:15 1rem;"><br><b>Cons:</b><div markdown="1" style="background:var(--background-modifier-border);padding:1rem;border-radius:6px;">`,
      ...consList.map(c => `- ${c}`),
      `</div></td>`,
      `</tr></table>`,
      ``,
      `**Purchase:** [${inputs.site.value.trim()}](${inputs.url.value.trim()})`
    ];

    const file = app.vault.getAbstractFileByPath(path);
    if (file) {
      msg.textContent = `❌ File already exists: ${path}`;
      return;
    }

    await app.vault.create(path, [...yaml, "", ...body].join("\n"));
    msg.textContent = `✅ Note created: ${path}`;

    // Reset all fields
    Object.values(inputs).forEach(i => i.value = "");
    prosArea.value = "";
    consArea.value = "";
    description.value = "";
  };
})();
```