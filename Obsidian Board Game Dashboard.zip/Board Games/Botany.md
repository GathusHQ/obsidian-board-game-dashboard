---
Title: Botany
Designer: Amy Droz, Dusty Droz
Year-Published: 2024
Cover-Img: https://cf.geekdo-images.com/keC0oy0nbpewpRTdcte42Q__imagepage@2x/img/Nf7AU5M7AuvD3nx0DCr1ty-QhxQ=/fit-in/1800x1200/filters:strip_icc()/pic7361181.png
Category: Adventure / Card / Dice Rolling / Pick-Up and Deliver / Set Collection
Solo-Play: Yes
Co-op: No
Player-Count: 1 - 5
Play-Time: 45 - 90 Minutes
Star-Rating: 5
tags:
  - Board-Games/Adventure
  - Board-Games/Card
  - Board-Games/Dice-Rolling
  - Board-Games/Pick-Up-and-Deliver
  - Board-Games/Set-Collection
pros:
  1. First item here.
  2. Second item here.
  3. Third item here.
cons:
  4. First item here.
  5. Second item here.
  6. Third item here.
Purchase-URL: https://www.amazon.com/dp/B0CGCC7C8C
Purchase-Site: Amazon
---

### Botany

```dataviewjs
// ---------- CSS ----------
const style = document.createElement("style");
style.textContent = `
.game-info-grid {
  display: grid;
  grid-template-columns: 200px 1fr 1fr;
  gap: 1.5rem;
  margin: 0.5rem 0;
}
.game-info-card {
  padding: 1rem;
  border: 1px solid var(--background-modifier-border);
  border-radius: 8px;
  background-color: var(--background-secondary);
}
.game-info-card h3 {
  margin: 0 0 0.5rem 0;
  font-size: 1.1em;
  font-weight: 600;
}
.game-info-card p {
  margin: 0.2rem 0;
}
`;
document.head.appendChild(style);

// ---------- DATA ----------
const page = dv.current();
const categories = page.Category
  ? page.Category.split("/").map(s => s.trim())
  : [];

// ---------- RENDER ----------
const container = dv.container.createDiv({ cls: "game-info-grid" });

// Column 1: cover image
const col1 = container.createDiv();
col1.innerHTML = `<img src="${page["Cover-Img"] || ""}" style="width:200px;border-radius:6px;">`;

// Column 2: Categories
const col2 = container.createDiv({ cls: "game-info-card" });
col2.createEl("h3", { text: "Categories" });
categories.forEach(c => col2.createEl("p", { text: c }));

// Column 3: Stats
const col3 = container.createDiv({ cls: "game-info-card" });
col3.createEl("h3", { text: "Stats" });
if (page.Designer) col3.createEl("p", { text: `Designer: ${page.Designer}` });
if (page["Solo-Play"]) col3.createEl("p", { text: `Solo-Play: ${page["Solo-Play"]}` });
if (page["Co-op"]) col3.createEl("p", { text: `Co-op: ${page["Co-op"]}` });
if (page["Player-Count"]) col3.createEl("p", { text: `Player Count: ${page["Player-Count"]}` });
if (page["Play-Time"]) col3.createEl("p", { text: `Play Time: ${page["Play-Time"]}` });
```

---

Adventure, intrigue, and flowers! Botany is a strategy board game where you take on the role of a Victorian Era flower hunter as you explore the world to gather fortune and fame and be named the Royal Botanist. In Botany, each player takes on the role of a character whose abilities will shape the way they play the game. Will you focus on exploring the globe in search of the most valuable specimens? Will you make quick and efficient trips to gather reputation quickly and build your estate?

Each player begins the game with a set of randomized goals that they then use to plot their path to victory. When players set out from their estate, they have access only to the coins they can carry with them. They can use these coins to traverse the globe and gain crew members and items to improve their odds of surviving the unknown, enhance their abilities, and increase the efficiency with which they traverse the map. However, there is danger in spending too freely, and players must ensure they have enough wealth on hand to return to England with their specimens intact.

Turns in Botany are streamlined in order to minimize downtime and keep players engaged. Players will move around the map, build their character, and experience the story of their rise to fame, all with an eye for efficiency. Points are gained by improving the quality of your garden, retrieving live specimens from around the globe, and adding preserved flowers to your botanical press. The specimens that players hunt, the goals they focus on to achieve victory, and the events they experience create a unique feel across each game.

- EXPERIENCE THE THRILL OF THE HUNT!: Take on the role of a plant hunter in the Victorian Era as you travel the world in search of fame, fortune, and the coveted Queen’s Prize in Botany. Earn the most points by collecting and safely returning botanical specimens to your growing English estate.
- ADVENTURE AND DANGER IN SEARCH OF FAME AND FORTUNE: Botany’s characters and events paint a story as you traverse the globe to become the ultimate flower hunter. While some of the game's events may seem too far-fetched to be true, they're actually loosely based on real-life occurrences.
- SIMPLE TO LEARN WITH STRATEGIC GAMEPLAY: Botany has a simple and intuitive rule system, allowing players to quickly learn the game and jump right into the action without the need to read lengthy rule books. Randomized specimens and various paths to victory make each expedition fresh and unique, providing players of all skill levels with exciting gameplay and lots of replayability.
- HEIRLOOM QUALITY MATERIALS: Crafted with an expert level of attention to detail, Botany’s components and intricate illustrations result in a truly tactile and immersive experience that rivals the books and maps of the Victorian era. Playing the game is not just a fun activity, but a true sensory experience that transports players back in time.
- NUMBER OF PLAYERS AND AVERAGE PLAYTIME: This fun strategy game is designed for 1-5 players and is suitable for ages 8 and older. Average playtime is 45-90 minutes.

<!-- Pros / Cons Panel -->
<table style="width:100%;border-collapse:collapse;margin:2rem 0;"><tr>
<td style="width:50%;vertical-align:top;padding:15 1rem;"><br><b>Pros:</b><div markdown="1" style="background:var(--background-modifier-border);padding:1rem;border-radius:6px;">
- This is an absolutely beautiful game.
- Light to medium complexity.
- Very easy rules.
</div></td>
<td style="width:50%;vertical-align:top;padding:15 1rem;"><br><b>Cons:</b><div markdown="1" style="background:var(--background-modifier-border);padding:1rem;border-radius:6px;">
- First item here.
- Second item here.
- Third item here.
</div></td>
</tr></table>

**Purchase:** [Amazon](https://www.amazon.com/dp/B0CGCC7C8C)