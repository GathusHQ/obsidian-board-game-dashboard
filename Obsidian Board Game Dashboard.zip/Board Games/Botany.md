---
Title: Botany
Designer: Amy Droz, Dusty Droz
Year-Published: 2024
Cover-Img: https://cf.geekdo-images.com/keC0oy0nbpewpRTdcte42Q__imagepage@2x/img/Nf7AU5M7AuvD3nx0DCr1ty-QhxQ=/fit-in/1800x1200/filters:strip_icc()/pic7361181.png
Category: Adventure / Card / Dice Rolling / Pick-Up and Deliver / Set Collection
Solo-Play: Yes
Co-op: No
Player-Count: 1 - 5
Play-Time: 45 - 90 Minutes
Star-Rating: 5
tags:
  - Board-Games/Adventure
  - Board-Games/Card
  - Board-Games/Dice-Rolling
  - Board-Games/Pick-Up-and-Deliver
  - Board-Games/Set-Collection
pros:
  1. First item here.
  2. Second item here.
  3. Third item here.
cons:
  4. First item here.
  5. Second item here.
  6. Third item here.
Purchase-URL: https://www.amazon.com/dp/B0CGCC7C8C
Purchase-Site: Amazon
---

### Botany

![Botany cover|200](https://cf.geekdo-images.com/keC0oy0nbpewpRTdcte42Q__imagepage@2x/img/Nf7AU5M7AuvD3nx0DCr1ty-QhxQ=/fit-in/1800x1200/filters:strip_icc()/pic7361181.png)

---

Adventure, intrigue, and flowers! Botany is a strategy board game where you take on the role of a Victorian Era flower hunter as you explore the world to gather fortune and fame and be named the Royal Botanist. In Botany, each player takes on the role of a character whose abilities will shape the way they play the game. Will you focus on exploring the globe in search of the most valuable specimens? Will you make quick and efficient trips to gather reputation quickly and build your estate?

Each player begins the game with a set of randomized goals that they then use to plot their path to victory. When players set out from their estate, they have access only to the coins they can carry with them. They can use these coins to traverse the globe and gain crew members and items to improve their odds of surviving the unknown, enhance their abilities, and increase the efficiency with which they traverse the map. However, there is danger in spending too freely, and players must ensure they have enough wealth on hand to return to England with their specimens intact.

Turns in Botany are streamlined in order to minimize downtime and keep players engaged. Players will move around the map, build their character, and experience the story of their rise to fame, all with an eye for efficiency. Points are gained by improving the quality of your garden, retrieving live specimens from around the globe, and adding preserved flowers to your botanical press. The specimens that players hunt, the goals they focus on to achieve victory, and the events they experience create a unique feel across each game.

- EXPERIENCE THE THRILL OF THE HUNT!: Take on the role of a plant hunter in the Victorian Era as you travel the world in search of fame, fortune, and the coveted Queen’s Prize in Botany. Earn the most points by collecting and safely returning botanical specimens to your growing English estate.
- ADVENTURE AND DANGER IN SEARCH OF FAME AND FORTUNE: Botany’s characters and events paint a story as you traverse the globe to become the ultimate flower hunter. While some of the game's events may seem too far-fetched to be true, they're actually loosely based on real-life occurrences.
- SIMPLE TO LEARN WITH STRATEGIC GAMEPLAY: Botany has a simple and intuitive rule system, allowing players to quickly learn the game and jump right into the action without the need to read lengthy rule books. Randomized specimens and various paths to victory make each expedition fresh and unique, providing players of all skill levels with exciting gameplay and lots of replayability.
- HEIRLOOM QUALITY MATERIALS: Crafted with an expert level of attention to detail, Botany’s components and intricate illustrations result in a truly tactile and immersive experience that rivals the books and maps of the Victorian era. Playing the game is not just a fun activity, but a true sensory experience that transports players back in time.
- NUMBER OF PLAYERS AND AVERAGE PLAYTIME: This fun strategy game is designed for 1-5 players and is suitable for ages 8 and older. Average playtime is 45-90 minutes.

<!-- Pros / Cons Panel -->
<table style="width:100%;border-collapse:collapse;margin:2rem 0;"><tr>
<td style="width:50%;vertical-align:top;padding:15 1rem;"><br><b>Pros:</b><div markdown="1" style="background:var(--background-modifier-border);padding:1rem;border-radius:6px;">
- This is an absolutely beautiful game.
- Light to medium complexity.
- Very easy rules.
</div></td>
<td style="width:50%;vertical-align:top;padding:15 1rem;"><br><b>Cons:</b><div markdown="1" style="background:var(--background-modifier-border);padding:1rem;border-radius:6px;">
- First item here.
- Second item here.
- Third item here.
</div></td>
</tr></table>

**Purchase:** [Amazon](https://www.amazon.com/dp/B0CGCC7C8C)