# 🎲 **My Board Game Dashboard**

```dataviewjs
(async () => {
  try {
    // ── 0) Config ───────────────────────────────────────────
    const GAMES_PER_PAGE = 10;

    // ── 1) Lightbox viewer (unchanged) ──────────────────────
    const OVERLAY_ID = "dvjs-bg-image-overlay";
    if (!document.getElementById(OVERLAY_ID)) {
      const overlay = document.createElement("div");
      overlay.id = OVERLAY_ID;
      Object.assign(overlay.style, {
        position: "fixed", top: 0, left: 0,
        width: "100vw", height: "100vh",
        background: "rgba(0,0,0,0.85)",
        display: "none", alignItems: "center", justifyContent: "center",
        zIndex: 9999, cursor: "pointer"
      });
      const img = document.createElement("img");
      Object.assign(img.style, {
        maxWidth: "95%", maxHeight: "95%",
        borderRadius: "4px", pointerEvents: "none",
        boxShadow: "0 4px 12px rgba(0,0,0,0.5)"
      });
      overlay.appendChild(img);
      overlay.addEventListener("click", () => overlay.style.display = "none");
      document.body.appendChild(overlay);
    }
    const showOverlay = src => {
      const overlay = document.getElementById(OVERLAY_ID);
      overlay.querySelector("img").src = src;
      overlay.style.display = "flex";
    };

    // ── 2) Styles (updated for button and table positioning) ─
    const STYLE_ID = "dvjs-boardgames-style";
    document.getElementById(STYLE_ID)?.remove();
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      .dv-table[data-dv-boardgames] { 
        width:100% !important; 
        border:none; 
        border-collapse:collapse; 
        table-layout:fixed !important; 
        margin-top: 0 !important; /* Ensure no top margin */
      }
      .dv-table[data-dv-boardgames] th, .dv-table[data-dv-boardgames] td {
        padding:4px; border:none; vertical-align:top !important; text-overflow:ellipsis; overflow:hidden; white-space:nowrap;
      }
      .dv-table[data-dv-boardgames] .cover-col     { width: 80px; }
      .dv-table[data-dv-boardgames] .title-col     { width: 200px; }
      .dv-table[data-dv-boardgames] .published-col { width: 80px; }
      .dv-table[data-dv-boardgames] .category-col  { width: 150px; }
      .dv-table[data-dv-boardgames] .players-col   { width: 80px; text-align:center; }
      .dv-table[data-dv-boardgames] .rating-col    { width: 100px; }
      .dv-table[data-dv-boardgames] img {
        width:70px !important; height:auto; border-radius:4px; box-shadow:0 2px 6px rgba(0,0,0,0.3); cursor:zoom-in;
      }
      .dv-table[data-dv-boardgames] .rating-col input[type=range] { width:80px; }
      .dv-table[data-dv-boardgames] .pagination-controls {
        margin-top: 8px;
        display: flex;
        gap: 8px;
        align-items: center;
      }
      .dv-table[data-dv-boardgames] .pagination-controls button {
        padding: 4px 8px;
        border-radius: 4px;
        cursor: pointer;
      }
      .dv-table[data-dv-boardgames] .pagination-controls button:disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }
      .theme-dark .show-all-btn.active {
        background-color: var(--text-faint) !important;
        color: var(--background-primary) !important;
      }
      .show-all-btn {
        padding: 4px 12px 4px 8px; /* Increased right padding */
        border-radius: 4px;
        cursor: pointer;
        margin-left: 1px; /* User-specified */
        white-space: nowrap;
        min-width: 120px; /* Ensure button is wide enough for text */
      }
      .show-all-cell {
        white-space: nowrap;
        padding: 4px;
      }
      .table-holder {
        margin-top: 0 !important; /* Ensure table starts at top */
        padding-top: 0 !important;
      }
    `;
    document.head.appendChild(style);

    // ── 3) Load all game pages ───────────────────────────────
    const allGames = dv.pages('"Board Games"')
                       .sort(g => g.file.name);
    const splitRegex = /\/|:|>/;
    const rawCats = allGames.flatMap(g => Array.isArray(g.Category) ? g.Category : [g.Category ?? ""]);
    const segments = rawCats.flatMap(c => c.toString().split(splitRegex).map(p => p.trim())).filter(Boolean);
    const categories = ["All", ...Array.from(new Set(segments)).sort()];

    // ── 4) Build the toolbar ─────────────────────────────────
    const root = dv.container;
    root.empty();
    const toolbar = root.createEl("table", { style: "width:100%; border-collapse:collapse; margin-bottom:12px;" });
    const tr = toolbar.insertRow();

    // Filter label
    const lblCell = tr.insertCell();
    lblCell.textContent = "Filter by Category:";
    lblCell.style.cssText = "padding:4px 0; white-space:nowrap; font-size:18px; font-weight:normal; margin-right:6px;";

    // Dropdown
    const selCell = tr.insertCell();
    const sel = selCell.createEl("select");
    sel.style.padding = "4px 8px";
    categories.forEach(cat => sel.createEl("option", { text: cat, attr: { value: cat } }));
    const savedCategory = localStorage.getItem("dvjs-bg-category") || "All";
    if (categories.includes(savedCategory)) sel.value = savedCategory;

    // Surprise Me! button
    const btnCell = tr.insertCell();
    const btn = btnCell.createEl("button", { text: "🎲 Surprise Me!" });
    btn.style.padding = "4px 8px"; btn.style.cursor = "pointer";

    // Show All button
    const showAllCell = tr.insertCell();
    showAllCell.classList.add("show-all-cell");
    const showAllBtn = showAllCell.createEl("button", { text: "📜 Show All Games ", cls: "show-all-btn", attr: { title: "Toggle Show All Games" } });
    showAllBtn.style.cssText = "padding:4px 12px 4px 8px; border-radius:4px; cursor:pointer; margin-left:1px;";
    let isShowAll = localStorage.getItem("dvjs-bg-show-all") === "true";
    showAllBtn.classList.toggle("active", isShowAll);

    // Spacer
    tr.insertCell().style.width = "100%";

    // Search box
    const searchCell = tr.insertCell();
    const searchInput = searchCell.createEl("input", { attr: { type: "text", placeholder: "Search title…" } });
    searchInput.style.padding = "4px 8px"; searchInput.style.width = "200px";
    const savedSearch = localStorage.getItem("dvjs-bg-search") || "";
    searchInput.value = savedSearch;

    // ── 5) Rating helpers ────────────────────────────────────
    function parseRating(g) {
      const raw = g.rating ?? g["Star-Rating"];
      if (typeof raw === "number") return raw;
      if (typeof raw === "string") {
        const n = Number(raw);
        if (!isNaN(n)) return n;
        return [...raw].filter(c => c === "★").length;
      }
      return 0;
    }
    async function writeRating(path, newRating) {
      const file = app.vault.getAbstractFileByPath(path);
      let txt = await app.vault.read(file);
      const m = txt.match(/^---\n([\s\S]*?)\n---/);
      if (!m) return;
      let fm = m[1];
      if (/^Star-Rating:.*$/m.test(fm)) {
        fm = fm.replace(/^Star-Rating:.*$/m, `Star-Rating: ${newRating}`);
      } else {
        fm += `\nStar-Rating: ${newRating}`;
      }
      await app.vault.modify(file, `---\n${fm}\n---` + txt.slice(m[0].length));
    }

    // ── 6) Filter & draw logic ───────────────────────────────
    const tableHolder = root.createDiv({ cls: "table-holder" });
    const paginationHolder = root.createDiv({ cls: "pagination-controls" });
    let filteredGames = allGames;
    let lastPage = Number(localStorage.getItem("dvjs-bg-page") || 1);

    function getFilteredList() {
      const term = searchInput.value.toLowerCase();
      return allGames.filter(g => {
        const inTitle = g.file.name.toLowerCase().includes(term);
        if (sel.value !== "All") {
          const cats = Array.isArray(g.Category) ? g.Category : [g.Category ?? ""];
          return inTitle && cats.some(c => c.split(splitRegex).map(x => x.trim()).includes(sel.value));
        }
        return inTitle;
      });
    }

    function renderTable(list, page = 1) {
      // Save scroll position
      const scrollTop = tableHolder.scrollTop || window.scrollY;

      tableHolder.empty();
      paginationHolder.empty();

      // Pagination calculations (skipped if Show All)
      let pageGames = list;
      let currentPage, totalPages;
      if (!isShowAll) {
        const totalGames = list.length;
        totalPages = Math.max(1, Math.ceil(totalGames / GAMES_PER_PAGE));
        currentPage = Math.min(page, totalPages);
        const startIdx = (currentPage - 1) * GAMES_PER_PAGE;
        const endIdx = startIdx + GAMES_PER_PAGE;
        pageGames = list.slice(startIdx, endIdx);
      } else {
        currentPage = 1;
        totalPages = 1;
      }

      // Render table
      const tbl = tableHolder.createEl("table", { cls: "dv-table", attr: { "data-dv-boardgames": "" } });
      const thead = tbl.createEl("thead").createEl("tr");
      ["Cover", "Title", "Published", "Category", "Players", "My Rating"].forEach((h, i) => {
        thead.createEl("th", {
          text: `${h}${i === 0 ? ` (${list.length})` : ""}`,
          cls: ["cover-col", "title-col", "published-col", "category-col", "players-col", "rating-col"][i],
          style: "padding:4px;border-bottom:1px solid var(--text-faint)"
        });
      });
      const tbody = tbl.createEl("tbody");
      pageGames.forEach(g => {
        const row = tbody.createEl("tr");
        row.dataset.path = g.file.path; // Store path for easy lookup
        // Cover
        row.createEl("td", { cls: "cover-col" })
           .createEl("img", { attr: { src: g["Cover-Img"] } })
           .addEventListener("mousedown", e => { e.preventDefault(); showOverlay(g["Cover-Img"]); });
        // Title
        row.createEl("td", { cls: "title-col" })
           .createEl("a", { text: g.file.name, cls: "internal-link", attr: { "data-href": g.file.path } });
        // Published
        row.createEl("td", { cls: "published-col", text: g["Year-Published"]?.toString() || "" });
        // Category
        row.createEl("td", { cls: "category-col", text: Array.isArray(g.Category) ? g.Category.join(", ") : g.Category || "" });
        // Players
        row.createEl("td", { cls: "players-col", text: g["Player-Count"]?.toString() || "" });
        // Rating slider
        const rc = row.createEl("td", { cls: "rating-col" });
        const init = parseRating(g);
        const slider = rc.createEl("input", { attr: { type: "range", min: 0, max: 5, step: 1, value: init } });
        slider.style.width = "80px";
        const lbl = rc.createEl("span", { text: ` ${init}`, style: "margin-left:6px;" });
        let sliderTimeout;
        slider.addEventListener("input", () => {
          const v = slider.valueAsNumber;
          lbl.textContent = ` ${v}`;
          clearTimeout(sliderTimeout);
          sliderTimeout = setTimeout(async () => {
            await writeRating(g.file.path, v);
            const gameIdx = filteredGames.findIndex(game => game.file.path === g.file.path);
            if (gameIdx !== -1) {
              filteredGames[gameIdx] = { ...filteredGames[gameIdx], "Star-Rating": v };
            }
            // Update only the affected row
            const row = tbody.querySelector(`tr[data-path="${g.file.path}"]`);
            if (row) {
              const ratingCell = row.querySelector(".rating-col");
              const currentSlider = ratingCell.querySelector("input[type=range]");
              const currentLabel = ratingCell.querySelector("span");
              currentSlider.value = v;
              currentLabel.textContent = ` ${v}`;
            }
          }, 300);
        });
      });

      // Pagination controls (only if not Show All)
      if (!isShowAll && list.length > GAMES_PER_PAGE) {
        const prevBtn = paginationHolder.createEl("button", { text: "Previous" });
        prevBtn.disabled = currentPage === 1;
        const pageInfo = paginationHolder.createEl("span", { text: ` Page ${currentPage} of ${totalPages} ` });
        const nextBtn = paginationHolder.createEl("button", { text: "Next" });
        nextBtn.disabled = currentPage === totalPages;

        prevBtn.addEventListener("click", () => {
          if (currentPage > 1) {
            localStorage.setItem("dvjs-bg-page", currentPage - 1);
            renderTable(filteredGames, currentPage - 1);
          }
        });
        nextBtn.addEventListener("click", () => {
          if (currentPage < totalPages) {
            localStorage.setItem("dvjs-bg-page", currentPage + 1);
            renderTable(filteredGames, currentPage + 1);
          }
        });
      }

      // Reinforce button state
      showAllBtn.classList.toggle("active", isShowAll);

      // Set initial scroll position to top
      window.scrollTo(0, 0);
    }

    // ── 7) Centralized update function ───────────────────────
    function updateTable() {
      filteredGames = getFilteredList();
      const totalPages = isShowAll ? 1 : Math.max(1, Math.ceil(filteredGames.length / GAMES_PER_PAGE));
      const currentPage = isShowAll ? 1 : Math.min(lastPage, totalPages);
      localStorage.setItem("dvjs-bg-page", currentPage);
      renderTable(filteredGames, currentPage);
    }

    // ── 8) Bind controls with debounced search ───────────────
    sel.addEventListener("change", () => {
      localStorage.setItem("dvjs-bg-category", sel.value);
      localStorage.setItem("dvjs-bg-page", 1);
      lastPage = 1;
      updateTable();
    });
    showAllBtn.addEventListener("click", () => {
      isShowAll = !isShowAll;
      localStorage.setItem("dvjs-bg-show-all", isShowAll);
      if (!isShowAll) {
        localStorage.setItem("dvjs-bg-page", lastPage);
      } else {
        lastPage = Number(localStorage.getItem("dvjs-bg-page") || 1);
        localStorage.setItem("dvjs-bg-page", 1);
      }
      showAllBtn.classList.toggle("active", isShowAll);
      updateTable();
    });
    let searchTimeout;
    searchInput.addEventListener("input", () => {
      clearTimeout(searchTimeout);
      searchTimeout = setTimeout(() => {
        localStorage.setItem("dvjs-bg-search", searchInput.value);
        localStorage.setItem("dvjs-bg-page", 1);
        lastPage = 1;
        updateTable();
      }, 300);
    });
    btn.addEventListener("click", () => {
      const list = getFilteredList();
      if (!list.length) return alert("No matching games.");
      const pick = list[Math.floor(Math.random() * list.length)];
      app.workspace.openLinkText(pick.file.path, "", true);
    });

    // Initial render
    updateTable();

  } catch (err) {
    dv.paragraph("**🛑 Error in board game dashboard snippet:**");
    dv.codeblock(err.stack || err.toString(), "javascript");
  }
})();
```